package com.controller;

import java.net.URI;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.function.Consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.util.MultiValueMapAdapter;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.entity.Todo;
import com.repo.TodoRepo;

@CrossOrigin
@RestController
public class Controller {

	@Autowired
	TodoRepo todoRepo;
	
	@PostMapping("/todo")
	public ResponseEntity<Todo> addTodo(@RequestBody Todo todo){
		Todo t = todoRepo.addTodo(todo);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(t.getId()).toUri();
		HttpHeaders headers = new HttpHeaders();
		headers.add("location", location.toString());
		//return ResponseEntity.ok().headers(headers).build();
		return new ResponseEntity<Todo>(t,headers, HttpStatus.CREATED);
	}
	
	@GetMapping("/todo")
	public ResponseEntity<List<Todo>> getAllTodos(){
		List<Todo> list = todoRepo.getAllTodos();
		return new ResponseEntity<List<Todo>>(list, HttpStatus.FOUND);
	}
	
	@GetMapping("/todo/{id}")
	public ResponseEntity<Todo> getById(@PathVariable int id){
		Todo todo = todoRepo.getById(id);
		return new ResponseEntity<Todo>(todo, HttpStatus.FOUND);
	}
	
	@DeleteMapping("/todo")
	public ResponseEntity<Todo> deleteToDo(@RequestBody Todo toDo){
		todoRepo.deleteTodo(toDo);
		return ResponseEntity.noContent().build();
	}
	
	@DeleteMapping("/todo/{id}")
	public ResponseEntity<Todo> deleteTodoById(@PathVariable int id) {
		Todo todo = todoRepo.deleteTodoById(id);
		return new ResponseEntity<Todo>(todo, HttpStatus.NO_CONTENT);
	}
	
	@PutMapping("/todo")
	public ResponseEntity<Todo> updateTodo(@RequestBody Todo todo) {
		Todo updateTodo = todoRepo.updateTodo(todo);
		return new ResponseEntity<Todo>(updateTodo, HttpStatus.ACCEPTED);
	}

	
//	@SuppressWarnings("unchecked")
//	@GetMapping("/checks/1")
//	public <T> ResponseEntity<T> check1(){
//		User user = new User(1, "ABC");
//		ResponseEntity<T> res;    
//		if(user.getId()!=0) {
//			res = (ResponseEntity<T>) new ResponseEntity<User>(user, HttpStatus.FOUND);
//		}else {
//			res =  new ResponseEntity<T>((T) new CustomException("User id cannot be zero"), HttpStatus.NOT_ACCEPTABLE);
//		}
//		return (ResponseEntity<T>) res;
//	}
//	
//	@SuppressWarnings("unchecked")
//	@GetMapping("/check/{id}")
//	public <T> ResponseEntity<T> check(@PathVariable int id){
//		User user = new User(id, "ABC");
//		ResponseEntity<T> res;    
//		if(user.getId()!=0) {
//			res = (ResponseEntity<T>) new ResponseEntity<User>(user, HttpStatus.FOUND);
//		}else {
//			res =  new ResponseEntity<T>((T) new CustomException("User id cannot be zero"), HttpStatus.NOT_ACCEPTABLE);
//		}
//		return (ResponseEntity<T>) res;
//	}
//	
//	@SuppressWarnings("unchecked")
//	@DeleteMapping("/checks/{id}")
//	public <T> ResponseEntity<T> deleteToDo(@PathVariable String id){
//		return new ResponseEntity<T>(HttpStatus.ALREADY_REPORTED);
//	}
}

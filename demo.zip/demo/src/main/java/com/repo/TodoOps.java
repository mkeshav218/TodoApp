package com.repo;

import java.util.List;

import com.entity.Todo;

public interface TodoOps {
	public Todo addTodo(Todo todo);
	public List<Todo> getAllTodos();
	public Todo getById(int id);
	public Todo deleteTodo(Todo todo);
	public Todo deleteTodoById(int id);
	public Todo updateTodo(Todo todo);
}

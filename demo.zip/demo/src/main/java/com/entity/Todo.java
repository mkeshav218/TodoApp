package com.entity;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sun.istack.NotNull;

@Component
public class Todo {

	
	int id;
	
	@NotNull
	String description;
	LocalDateTime created;
	LocalDateTime modified;
	boolean isCompleted;
	
	public Todo() {
	}
	
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public LocalDateTime getCreated() {
		return created;
	}


	public void setCreated(LocalDateTime created) {
		this.created = created;
	}


	public LocalDateTime getModified() {
		return modified;
	}


	public void setModified(LocalDateTime modified) {
		this.modified = modified;
	}


	public boolean isCompleted() {
		return isCompleted;
	}


	public void setCompleted(boolean isCompleted) {
		this.isCompleted = isCompleted;
	}


	@Override
	public String toString() {
		return "Todo [id=" + id + ", description=" + description + ", created=" + created + ", modified=" + modified
				+ ", isCompleted=" + isCompleted + "]";
	}


	
	

}

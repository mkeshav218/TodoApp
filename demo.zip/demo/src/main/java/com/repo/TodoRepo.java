package com.repo;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.entity.Todo;

@Repository
@Transactional
public class TodoRepo implements TodoOps {

	private static List<Todo> list = new ArrayList<Todo>();
	private static int i=0;
	static {
		Todo todo = new Todo();
		todo.setId(++i);
		todo.setDescription("ABC");
		todo.setCompleted(false);
		list.add(todo);
		
		Todo todo1 = new Todo();
		todo1.setId(++i);
		todo1.setDescription("DEF");
		todo1.setCompleted(false);
		list.add(todo1);

		Todo todo2 = new Todo();
		todo2.setId(++i);
		todo2.setDescription("GHI");
		todo2.setCompleted(false);
		list.add(todo2);
	}
	
	public TodoRepo() {
	}

	@Override
	public Todo addTodo(Todo todo) {
		todo.setId(++i);
		list.add(todo);
		return todo;
	} 

	@Override
	public List<Todo> getAllTodos() {
		return list;
	}

	@Override
	public Todo getById(int id) {
		for(Todo todo:list) {
			if(todo.getId()==id) {
				return todo;
			}
		}
		return null;
	}

	@Override
	public Todo deleteTodo(Todo todo) {
		Todo deleteTodo = getById(todo.getId());
		list.remove(deleteTodo);
		return deleteTodo;
	}

	@Override
	public Todo deleteTodoById(int id) {
		Todo deleteTodo = getById(id);
		list.remove(deleteTodo);
		return deleteTodo;
	}

	@Override
	public Todo updateTodo(Todo todo) {
		Todo updateTodo = getById(todo.getId());
		updateTodo.setDescription(todo.getDescription());
		updateTodo.setCompleted(todo.isCompleted());
		return updateTodo;
	}

}
